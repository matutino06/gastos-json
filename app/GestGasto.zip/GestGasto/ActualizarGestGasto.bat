@echo off

:ESPERAR
tasklist | find /i "GestGasto.exe" >nul

if not errorlevel 1 (
    timeout /t 1 >nul
    goto ESPERAR
)

powershell -command "Expand-Archive -Path 'C:\Temp\GestGasto.zip' -DestinationPath 'C:\AppsGM\GestGasto' -Force"

start "" "C:\AppsGM\GestGasto\GestGasto.exe"