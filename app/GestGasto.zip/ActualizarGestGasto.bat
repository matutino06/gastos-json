@echo off
powershell -command "Expand-Archive -Path '%TEMP%\GestGasto.zip' -DestinationPath 'C:\AppsGM\GestGasto\tmp' -Force"

exit

