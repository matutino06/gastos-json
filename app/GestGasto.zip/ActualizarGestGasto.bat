@echo off

@echo "Paso 1"
:ESPERAR
tasklist | find /i "GestGasto.exe" >nul
@echo "Paso 2"

if not errorlevel 1 (
    timeout /t 1 >nul
    goto ESPERAR
)

@echo "Paso 3"
powershell -command "Expand-Archive -Path '%TEMP%\GestGasto.zip' -DestinationPath 'C:\AppsGM\GestGasto' -Force"
@echo "Paso 4"
start "" "C:\AppsGM\GestGasto\GestGasto.exe"
@echo "Paso 5"
exit

pause